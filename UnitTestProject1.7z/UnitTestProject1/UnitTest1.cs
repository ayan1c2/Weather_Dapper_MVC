﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Mvc;
using UnitTestProject1.controller;
using WebApplication2.Controllers;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void index()
        {
            ProductController controller = new ProductController();
            ViewResult result = controller.Index() as ViewResult;
            
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void TestDetailsView()
        {
            var controller = new ProductController();
            var result = controller.Details(2) as ViewResult;

            Assert.IsNotNull(result);
            Assert.AreEqual("Details", result.ViewName);

        }

        [TestMethod]
        public void CheckCountValueTest()
        {
            int count = 21;
            ProductController controller = new ProductController();
            ViewResult result = controller.CheckCountValue(count) as ViewResult;
            
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void About()
        {
            // Arrange
            ProductController controller = new ProductController();
            // Act
            var result = controller.About() as ViewResult;
            // Assert
            Assert.AreEqual("Your application description page.", result.ViewName);
        }

        [TestMethod]
        public void Contact()
        {
            // Arrange
            ProductController controller = new ProductController();
            // Act
            var result = controller.Contact() as ViewResult;
            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void Employees()
        {
            // Arrange
            EmployeeController controller = new EmployeeController();

            // Act
            ViewResult result1 = controller.Index() as ViewResult;
            ViewResult result2 = controller.Employees() as ViewResult;

            // Assert
            Assert.IsNotNull(result1);
            Assert.IsNotNull(result2);
        }


    }
}
