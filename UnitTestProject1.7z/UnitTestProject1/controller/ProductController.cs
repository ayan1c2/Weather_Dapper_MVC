﻿using System.Web.Mvc;
using System.Collections.Generic;
using System.Linq;
using System;

namespace WebApplication2.Controllers
{
    public class ProductController: Controller
    {
        public ActionResult Index()
        {
            // Add action logic here
            return View();
        }

        public ActionResult Details(int Id)
        {

            return View("Details");
        }

        public ActionResult CheckCountValue(int count)
        {
            if (count < 20)
            {
                //business logic goes here  
            }
            else
            {
                throw (new Exception("Out of the Range"));
            }

            return View();
        }

        public ActionResult About()
        {
            return View("Your application description page.");
        }

        public ActionResult Contact()
        {
            return View("Your contact page.");
        }
    }
}
