﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using UnitTestProject1.model;

namespace UnitTestProject1.controller
{
    public class EmployeeController : Controller
    {
        [NonAction]
        public List<Employee> GetEmployeeList()
        {
            return new List<Employee>{
            new Employee{
               ID = 1,
               Name = "X",
               JoiningDate = DateTime.Parse(DateTime.Today.ToString()),
               Age = 20
            },

            new Employee{
               ID = 2,
               Name = "Y",
               JoiningDate = DateTime.Parse(DateTime.Today.ToString()),
               Age = 40
            },

            new Employee{
               ID = 3,
               Name = "Z",
               JoiningDate = DateTime.Parse(DateTime.Today.ToString()),
               Age = 30
            },

            new Employee{
               ID = 4,
               Name = "Laura",
               JoiningDate = DateTime.Parse(DateTime.Today.ToString()),
               Age = 25
            },
         };
        }

        // GET: Employee
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Employees()
        {
            var employees = from e in GetEmployeeList()
                            orderby e.ID
                            select e;
            return View(employees);
        }
    }
}
